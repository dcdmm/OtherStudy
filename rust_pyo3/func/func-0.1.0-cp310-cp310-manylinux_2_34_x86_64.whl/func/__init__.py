from .func import *

__doc__ = func.__doc__
if hasattr(func, "__all__"):
    __all__ = func.__all__