from .class_py import *

__doc__ = class_py.__doc__
if hasattr(class_py, "__all__"):
    __all__ = class_py.__all__