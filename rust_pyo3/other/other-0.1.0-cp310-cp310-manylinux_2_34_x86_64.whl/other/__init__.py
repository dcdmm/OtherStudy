from .other import *

__doc__ = other.__doc__
if hasattr(other, "__all__"):
    __all__ = other.__all__